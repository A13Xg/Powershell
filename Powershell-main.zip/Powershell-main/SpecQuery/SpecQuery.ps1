
<#************************************************************************
Code written by A13Xg
Property of A13Xg
************************************************************************#>


## ABOUT
#This script's purpose is to assist in querying network computers for different specs

#region GLOBAL VARIABLES
    #Classification of Workstation/Network
        #// UNCLASSIFIED, SECRET, TOP SECRET, TS/SCI (Any other value will give the proper label and a blue banner)
[STRING]$global:Classification = "UNCLASSIFIED"
        #// Value of loading bar. 0-100
[INT]$global:ProgressBarValue = 0

$UseVerification = $False
$CompName = $tbCompName.Text
$DataSource = [PSCustomObject]@{
    ComputerName = $tbCompName.Text
    MakeModel = "$Manufacturer $Model"
    CPU = $CPU
    RAM = $RAM
    OS = $OperatingSystem
    VolumeID = $VolID
    gvsKey = "$GEMKEY1  $GEMKEY2"
    ipAddress = $IPAddressString
}
#endregion GLOBAL VARIABLES

#region EARLY LOGIC

#region CLASSIFICATION COLOR
    #// These IF Statements color the banner according to the setting specified above.
IF ($Classification -eq "UNCLASSIFIED") {
    [STRING]$global:BannerColor = "#15ff00"
}
ELSEIF ($Classification -eq "SECRET") {
    [STRING]$global:BannerColor = "#ff0000"

}
ELSEIF ($Classification -eq "TOP SECRET") {
    [STRING]$global:BannerColor = "#ff7b00"
}
ELSEIF ($Classification -eq "TS/SCI") {
    [STRING]$global:BannerColor = "#ffff00"
}
ELSE {
    [STRING]$global:BannerColor = "#0033ff"
}
#endregion CLASSIFICATION COLOR

#endregion EARLY LOGIC
#region FUNCTIONS
function LoadBar {
    #// LoadBar -Value <0-100>
    param (
        $Value
    )
    $global:ProgressBarValue = $Value
}
function TimeStamp {
    Get-Date -Format "MM/dd/yyyy-HH:mm"
}
function PopulateGrid {
    $DataSource = [PSCustomObject]@{
        ComputerName = $tbCompName.Text
        MakeModel = "$Manufacturer $Model"
        CPU = $CPU
        RAM = $RAM
        OS = $OperatingSystem
        VolumeID = $VolID
        gvsKey = "$GEMKEY1  $GEMKEY2"
        ipAddress = $IPAddressString
    }
    $DataGrid.AddChild($DataSource)
}
function ClearGrid {
    $DataGrid.ItemsSource = $null
    $DataGrid.Items.Clear()
}
function VerifyIntegrity {
    IF ($UseVerification -eq $True) {
         $testHash = HashItem -FilePath "SpecQuery.ps1" -HashType MD5
         $testHash1 = $testHash[1]
         $realHash = Get-Content -Path "VerifyIntegrity.dat"
         Write-Host $testHash1
         Write-Console -Message "File Hash: $testHash1" -Color "Cyan"
         IF ($testHash1 -eq $realHash[3]) {
             Write-Console -Message "Hash Verification: Success" -Color "Green"
         }
         ELSE {
             Write-Console -Message "Hash Verification: FAILURE" -Color "Red"
             Exit
         }
    }
    ELSE {
        Write-Host "Verification Disabled"
        Write-Console "Warning: Verification Disabled" -Color "RED"
    }
}
function OpenExplorer {
    explorer.exe "\\$CompName\C$"
}
function CheckAlive {
    $CompName = $tbCompName.Text
    Test-Connection -ComputerName $CompName -Count 2 -Quiet
}
function QuerySpecs {
    $CompName = $tbCompName.Text
            #// Query Remote Computer for CPU Name
        $global:CPU = Try {(Get-WmiObject -ErrorAction Stop -ComputerName $CompName Win32_Processor).Name} Catch {Write-Console -Message "Error: Could not get CPU" -Color "Red"}
            #// Query Remote Computer for RAM Amount
        $global:RAM = Try {(Get-WmiObject -ErrorAction Stop -ComputerName $CompName Win32_PhysicalMemory | Measure-Object -Property capacity -Sum).sum /1gb} Catch {Write-Console -Message "Error: Could not get RAM" -Color "Red"}
            #// Query Remote Computer for Operating System Insalled
        $global:OperatingSystem = Try {(Get-WmiObject -ErrorAction Stop -ComputerName $CompName Win32_OperatingSystem).Caption} Catch {Write-Console -Message "Error: Could not get Operating System" -Color "Red"}
            #// Query Remote Computer for Serail Number
        $global:SerialNumber = Try {(Get-WmiObject -ErrorAction Stop -ComputerName $CompName Win32_Bios).SerialNumber} Catch {Write-Console -Message "Error: Could not get Serial Number" -Color "Red"}
            #// Query Remote Computer for Manufacturer
        $global:Manufacturer = Try {(Get-WmiObject -ErrorAction Stop -ComputerName $CompName Win32_ComputerSystem).Manufacturer} Catch {Write-Console -Message "Error: Could not get Make" -Color "Red"}
            #// Query Remote Computer for Model
        $global:Model = Try {(Get-WmiObject -ErrorAction Stop -ComputerName $CompName Win32_ComputerSystem).Model} Catch {Write-Console -Message "Error: Could not get Model" -Color "Red"}
            #// Read the Contents of specified file (Default NTTR.red Domain Image places ICADS in this directory)
        $global:GEMKEY1 = Try {Get-Content "\\$CompName\C$\cubic\icads\GEMKEY\gvskey.txt" -ErrorAction Stop} Catch {Write-Console -Message "Warning: License file not found in 'C:\cubic\icads\GEMKEY\'" -Color "Yellow"}
            #// Read the Contents of specified file (Default Installation Directory for ICADS)
        $global:GEMKEY2 = Try {Get-Content "\\$CompName\C$\icads\GEMKEY\gvskey.txt" -ErrorAction Stop} Catch {Write-Console -Message "Warning: License file not found in 'C:\icads\GEMKEY\'" -Color "Yellow"}
        $global:VolID = Try {PSexec.exe \\$ComputerName cmd.exe vol} Catch {Write-Console -Message "Error: Could not remotely retrieve Volume ID"}
        $global:IPAddress = Try {Test-Connection -ComputerName $CompName -Count 1} Catch {Write-Console -Message "Error: Could not resolve IP Address"}
        $global:IPAddressString = ($IPAddress.IPV4Address).IPAddressToString
}
function InitiateUplink {

    (Clear-Console)
    $CompName = $tbCompName.Text
    Write-Console -Message "Testing Connection to $CompName... `n" -Color "White"
    IF(CheckAlive -eq $True) {
        Write-Console -Message "Uplink Established" -Color "Green"
        Write-Console -Message "Querying Info For $CompName..." -Color "Yellow"
        (QuerySpecs)
        (PopulateGrid)
    }
    ELSE {
        Write-Console -Message "Error: Unable to contact target $CompName" -Color "Red"
    }
}

function HashItem {
    param (
        [STRING] $FilePath,
        [STRING] $HashType
    )
    Certutil.exe -HashFile $FilePath $HashType
}
function Loginator {
    param (
        [STRING] $Message,
        [STRING] $Path
    )
    $Date = (TimeStamp)
    "[$Date] ~   $Message" | Out-File -FilePath $Path -Append
}
Function Write-Console {
    Param(
        [string]$Message,
        [string]$Color = "White"
    )

    $RichTextRange = New-Object System.Windows.Documents.TextRange( 
        $tbConsole.Document.ContentEnd,$tbConsole.Document.ContentEnd ) 
    $RichTextRange.Text = "$Message `n"
    $RichTextRange.ApplyPropertyValue( ( [System.Windows.Documents.TextElement]::ForegroundProperty ), $Color )  
    $tbConsole.ScrollToEnd()
}
Function Clear-Console {
    $RichTextRange = New-Object System.Windows.Documents.TextRange( 
        $tbConsole.Document.ContentStart,$tbConsole.Document.ContentEnd ) 
    $RichTextRange.Text = ""
}

#endregion FUNCTIONS
#region GUI
#-------------------------------------------------------------#
#----Initial Declarations-------------------------------------#
#-------------------------------------------------------------#

Add-Type -AssemblyName PresentationCore, PresentationFramework

$Xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Width="1000" Height="600" HorizontalAlignment="Left" VerticalAlignment="Top" Margin="-11,-6,0,0">
<Grid>
<Rectangle HorizontalAlignment="Left" VerticalAlignment="Top" Fill="$BannerColor" Stroke="Black" Height="30" Width="1000" Margin="0,0,0,0" Name="topbannerColor"/>
<Rectangle HorizontalAlignment="Left" VerticalAlignment="Top" Fill="$BannerColor" Stroke="Black" Height="30" Width="1000" Margin="0,531,0,0" Name="bottombannerColor"/>
<Label HorizontalAlignment="Center" VerticalAlignment="Top" Content="$Classification" Margin="0,0,0,0" Name="topbannerLabel" FontFamily="Courier New" FontSize="20"/>
<Label HorizontalAlignment="Center" VerticalAlignment="Top" Content="$Classification" Margin="0,531,0,0" Name="bottombannerLabel" FontFamily="Courier New" FontSize="20"/>
<Rectangle HorizontalAlignment="Left" VerticalAlignment="Top" Fill="#999c98" Stroke="Black" Height="501" Width="1000" Margin="0,30,0,0"/>
<DataGrid HorizontalAlignment="Left" VerticalAlignment="Top" Width="980" Height="100" Margin="5,425,5,5" Name="dataGrid" AutoGenerateColumns="False" FontSize="12" FontFamily="Consolas">
    <DataGrid.Columns>  
        <DataGridTextColumn Binding="{Binding ComputerName}" Header="Computer Name" IsReadOnly="True" Width="Auto"/>  
        <DataGridTextColumn Binding="{Binding MakeModel}" Header="Make/Model" IsReadOnly="True" Width="Auto"/>  
        <DataGridTextColumn Binding="{Binding CPU}" Header="CPU" IsReadOnly="True" Width="Auto"/>  
        <DataGridTextColumn Binding="{Binding RAM}" Header="RAM" IsReadOnly="True" Width="Auto"/>  
        <DataGridTextColumn Binding="{Binding OS}" Header="Operating System" IsReadOnly="True" Width="Auto"/>
        <DataGridTextColumn Binding="{Binding VolumeID}" Header="VolumeID" IsReadOnly="True" Width="Auto"/>
        <DataGridTextColumn Binding="{Binding gvsKey}" Header="License Key" IsReadOnly="True" Width="Auto"/>
        <DataGridTextColumn Binding="{Binding ipAddress}" Header="IP Address" IsReadOnly="True" Width="Auto"/>
    </DataGrid.Columns>  
</DataGrid>

<TextBox HorizontalAlignment="Left" VerticalAlignment="Top" Height="30" Width="247" TextWrapping="Wrap" Margin="175,55,0,0" Name="tbCompName" Background="#303030" Foreground="#ffffff" FontSize="18" FontFamily="Consolas Bold"/>
<Label HorizontalAlignment="Left" VerticalAlignment="Top" Content="Target Name:" Margin="18,55,0,0" Name="lbCompName" FontFamily="Courier New Bold" FontSize="20"/>
<Button Content="Initiate Uplink" HorizontalAlignment="Left" VerticalAlignment="Top" Width="275" Margin="465,55,0,0" Name="btnUplink" Height="30" FontFamily="Impact" FontSize="20" Background="#f8e71c"/>

<RichTextBox HorizontalAlignment="Left" VerticalAlignment="Top" Height="380" Width="215" Margin="772,35,6,0" IsReadOnly="True" Background="#000000" FontSize="12" FontFamily="Consolas" Name="tbConsole"/>
<ProgressBar HorizontalAlignment="Left" Height="8" VerticalAlignment="Top" Width="217" Margin="772,414,6,0" Foreground="#2e58ff" Value="$global:ProgressBarValue"/>


</Grid>
</Window>
"@
#endregion GUI

#-------------------------------------------------------------#
#----Script Execution-----------------------------------------#s
#-------------------------------------------------------------#

$Window = [Windows.Markup.XamlReader]::Parse($Xaml)

[xml]$xml = $Xaml

$xml.SelectNodes("//*[@Name]") | ForEach-Object { Set-Variable -Name $_.Name -Value $Window.FindName($_.Name) }

$btnUplink.Add_Click({InitiateUplink})


(ClearGrid)
(VerifyIntegrity)

$Window.ShowDialog()

