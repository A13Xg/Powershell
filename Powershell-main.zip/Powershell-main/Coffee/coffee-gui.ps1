<#
Code written by JTech676
Property of USAF // JT4 LLC
P5 Combat Training System
#>

## ABOUT
# This code prevents a mission critical system from going to sleep due to a forced Group Policy or other machine settings.
# This is accomplished by toggling the 'Scroll Lock' key on and off every 45 seconds.
# >NOTE< This application is NOT intended to circumvent security measures. When running this application ensure the system is physically supervised and protected.

function Image-Path {
$Loc = Get-Location
Join-Path -Path $Loc -ChildPath "\coffee-full.png"
}

function Image-PathEmpty {
$Loc = Get-Location
Join-Path -Path $Loc -ChildPath "\coffee-empty.png"
}

function Icon-Path {
$Loc = Get-Location
Join-Path -Path $Loc -ChildPath "\coffee.ico"
}

$ImgLoc = Image-Path
$ImgLocEmpty = Image-PathEmpty
$IconLoc = Icon-Path

function Status-Bang {
    $image.imageLocation = $ImgLoc
}

function Status-UnBang {
    $image.imageLocation = "$ImgLocEmpty"
}

function Stay-Awake {
    Status-Bang
    Start-Job -Name Wakey {
    Write-Host functionRan
        $WShell = New-Object -Com Wscript.Shell
        while (1) {$WShell.SendKeys("{SCROLLLOCK}{SCROLLLOCK}"); sleep 45}
        Write-Host functionRan2
    }
}

function Kill-Awake {
    Try {
        Stop-Job -Name Wakey
        Remove-Job -Name Wakey
        Status-UnBang
        }
    Catch {
        Write-Host No Job is currently running.
    }
    Finally {
    }
}


Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = New-Object System.Drawing.Point(161,207)
$Form.text                       = "Form"
$Form.TopMost                    = $false
$Form.Icon                       = $IconLoc

$image                           = New-Object system.Windows.Forms.PictureBox
$image.width                     = 147
$image.height                    = 121
$image.location                  = New-Object System.Drawing.Point(5,5)
$image.imageLocation             = ""
$image.SizeMode                  = [System.Windows.Forms.PictureBoxSizeMode]::zoom
$buttonBang                      = New-Object system.Windows.Forms.Button
$buttonBang.text                 = "Coffee!"
$buttonBang.width                = 144
$buttonBang.height               = 30
$buttonBang.location             = New-Object System.Drawing.Point(8,128)
$buttonBang.Font                 = New-Object System.Drawing.Font('Consolas',17,[System.Drawing.FontStyle]([System.Drawing.FontStyle]::Bold))
$buttonBang.BackColor            = [System.Drawing.ColorTranslator]::FromHtml("#7ed321")

$buttonUnbang                    = New-Object system.Windows.Forms.Button
$buttonUnbang.text               = "UN-Coffee!"
$buttonUnbang.width              = 144
$buttonUnbang.height             = 30
$buttonUnbang.location           = New-Object System.Drawing.Point(8,166)
$buttonUnbang.Font               = New-Object System.Drawing.Font('Consolas',17,[System.Drawing.FontStyle]([System.Drawing.FontStyle]::Bold))
$buttonUnbang.BackColor          = [System.Drawing.ColorTranslator]::FromHtml("#d0021b")

$Form.controls.AddRange(@($image,$buttonBang,$buttonUnbang))

$buttonBang.Add_Click({ Stay-Awake })
$buttonUnbang.Add_Click({ Kill-Awake })




#Write your logic code here

[void]$Form.ShowDialog()
